import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:mapbox_gl/mapbox_gl.dart';
import 'package:mapbox_turn_by_turn/helpers/shared_prefs.dart';
import 'package:mapbox_turn_by_turn/main.dart';
import 'package:mapbox_turn_by_turn/screens/prepare_ride.dart';

import '../helpers/mapbox_handler.dart';
import 'turn_by_turn.dart';

class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  LatLng currentLocation = getCurrentLatLngFromSharedPrefs();
  LatLng? goingTo;
  late String currentAddress;
  String goingToAddress = "";
  late CameraPosition _initialCameraPosition;
  late MapboxMapController controller;

  bool isToLocationPick = false;

  @override
  void initState() {
    super.initState();
    _initialCameraPosition = CameraPosition(target: currentLocation, zoom: 14);
    currentAddress = getCurrentAddressFromSharedPrefs();
  }

  _onMapCreated(MapboxMapController controller) async {
    this.controller = controller;
  }

  _addSourceAndLineLayer(geometry) async {
    // Create a polyLine between source and destination
    final _fills = {
      "type": "FeatureCollection",
      "features": [
        {
          "type": "Feature",
          "id": 0,
          "properties": <String, dynamic>{},
          "geometry": geometry,
        },
      ],
    };

    await controller.removeLayer("lines");
    await controller.removeSource("fills");

    // Add new source and lineLayer
    await controller.addSource("fills", GeojsonSourceProperties(data: _fills));
    await controller.addLineLayer(
      "fills",
      "lines",
      LineLayerProperties(
        lineColor: Colors.indigo.toHexStringRGB(),
        lineCap: "round",
        lineJoin: "round",
        lineWidth: 1,
      ),
    );
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Row(
            children: const [
              Icon(
                CupertinoIcons.car_detailed,
                color: Colors.white,
              ),
              SizedBox(width: 10),
              Text('Vaistra Cabs'),
            ],
          ),
          actions: [
            IconButton(
                onPressed: () async {
                  await Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (contect) => const PrepareRide()),
                  );

                  if ((sharedPreferences.getString("source") ?? "")
                          .isNotEmpty &&
                      (sharedPreferences.getString("destination") ?? "")
                          .isNotEmpty) {
                    newPath(
                      getTripLatLngFromSharedPrefs('source'),
                      getTripLatLngFromSharedPrefs('destination'),
                    );

                    setState(() {
                      currentLocation = getTripLatLngFromSharedPrefs('source');
                      goingTo = getTripLatLngFromSharedPrefs('destination');
                      currentAddress =
                          getSourceAndDestinationPlaceText("source");
                      goingToAddress =
                          getSourceAndDestinationPlaceText("destination");
                    });
                  }
                },
                icon: const Icon(CupertinoIcons.search))
          ],
        ),
        body: Stack(
          children: [
            MapboxMap(
                accessToken: dotenv.env['MAPBOX_ACCESS_TOKEN'],
                initialCameraPosition: _initialCameraPosition,
                myLocationEnabled: true,
                onMapCreated: _onMapCreated,
                onMapClick: (point, latlong) {
                  if (isToLocationPick) {
                    clearMap();
                    getParsedReverseGeocoding(latlong).then((value) {
                      setState(() {
                        currentLocation = latlong;
                        currentAddress = value['place'];
                        isToLocationPick = false;
                      });

                      controller.addSymbol(SymbolOptions(
                        geometry: latlong,
                        iconImage: "assets/icon/mappin.png",
                        iconSize: 0.8,
                      ));
                    });
                    return;
                  }

                  newPath(currentLocation, latlong);
                  getParsedReverseGeocoding(latlong).then((value) {
                    setState(() {
                      goingTo = latlong;
                      goingToAddress = value['place'];
                    });
                  });
                }),
            Positioned(
              bottom: 0,
              child: SizedBox(
                width: MediaQuery.of(context).size.width,
                child: Card(
                  clipBehavior: Clip.antiAlias,
                  child: Padding(
                    padding: const EdgeInsets.all(15),
                    child: Row(
                      children: [
                        Expanded(
                          child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                InkWell(
                                  onTap: () {
                                    setState(() {
                                      isToLocationPick = true;
                                    });
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(
                                        content:
                                            Text('Pick new pick-up location!'),
                                      ),
                                    );
                                  },
                                  child: Row(
                                    children: [
                                      const Icon(Icons.pin_drop),
                                      const SizedBox(
                                        width: 10,
                                      ),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            const Text('You are here:'),
                                            Text(currentAddress,
                                                style: const TextStyle(
                                                    color: Colors.indigo)),
                                            const SizedBox(height: 20),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                if (goingToAddress.isNotEmpty) ...[
                                  const Text('Going to:'),
                                  Text(goingToAddress,
                                      style: const TextStyle(
                                          color: Colors.indigo)),
                                  const SizedBox(height: 20),
                                ]
                              ]),
                        ),
                        if (goingToAddress.isNotEmpty && goingTo != null)
                          FloatingActionButton(
                            onPressed: () async {
                              final ans = await showDialog(
                                context: context,
                                builder: (context) => TurnByTurn(
                                  source: currentLocation,
                                  destination: goingTo!,
                                ),
                              );

                              if (ans) {
                                setState(() {
                                  currentAddress =
                                      getCurrentAddressFromSharedPrefs();
                                  currentLocation =
                                      getCurrentLatLngFromSharedPrefs();
                                  goingToAddress = "";
                                  goingTo = null;
                                });
                                clearMap();
                                controller.animateCamera(
                                  CameraUpdate.newLatLng(currentLocation),
                                );
                              }
                            },
                            child: const Icon(Icons.navigation),
                          ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ));
  }

  clearMap() async {
    controller.clearSymbols();
    await controller.removeLayer("lines");
    await controller.removeSource("fills");
  }

  newPath(LatLng from, LatLng to) async {
    controller.clearSymbols();
    controller.addSymbol(
      SymbolOptions(
        geometry: from,
        iconImage: "assets/icon/mappin.png",
        iconSize: 0.8,
      ),
    );
    controller.addSymbol(
      SymbolOptions(
        geometry: to,
        iconImage: "assets/icon/mappin.png",
        iconSize: 0.8,
      ),
    );

    getDirectionsAPIResponse(from, to).then((modifiedResponse) {
      _addSourceAndLineLayer(modifiedResponse["geometry"]);
    });
  }
}
